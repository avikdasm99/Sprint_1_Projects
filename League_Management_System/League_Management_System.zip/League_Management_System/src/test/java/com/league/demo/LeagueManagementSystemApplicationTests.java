package com.league.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeagueManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
